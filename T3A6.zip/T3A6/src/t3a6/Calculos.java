/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package t3a6;

/**
 *
 * @author Cody
 */
public class Calculos {
    private int Empleado;
    private int añosAnt;
    private double salarioB;
    private double bono;
    private double isr;

    public Calculos() {
    }

    @Override
    public String toString() {
        String resultados = "Su salario bruto es: "+salarioB+"\nSu bono por antiguedad es de: "+bono+"\nSu retencion de ISR es de: "+isr+
                "\n\nSu salario total es de: "+(bono-isr);
        return resultados;
    }

    public Calculos(int tipoEmpleado, int añosAntiguedad, double salarioBase, double bono, double isr) {
        this.Empleado = tipoEmpleado;
        this.añosAnt = añosAntiguedad;
        this.salarioB = salarioBase;
        this.bono = bono;
        this.isr = isr;
    }

    public int getTipoEmpleado() {
        return Empleado;
    }

    public void setTipoEmpleado(int Empleado) {
        this.Empleado = Empleado;
    }

    public int getAñosAntiguedad() {
        return añosAnt;
    }

    public void setAñosAntiguedad(int añosAnt) {
        this.añosAnt = añosAnt;
    }

    public double getSalarioBase() {
        return salarioB;
    }

    public void setSalarioBase(double salarioB) {
        this.salarioB = salarioB;
    }
    
    public double getBono() {
    
        if(añosAnt >2 && añosAnt <6){
            bono = salarioB +(0.03*salarioB);
            if(Empleado==1){
            bono = bono +(0.01*salarioB);
            }
        }else if(añosAnt >5 && añosAnt <11){
            bono = salarioB +(0.08*salarioB);
            if(Empleado==1){
            bono = bono +(0.04*salarioB);
            }
        } else{
        bono=0;
        }
        return bono;
    }

    public void setBono(double bono) {
        this.bono = bono;
    }
    
    public double getIsr() {
        if(salarioB >=0.01 && salarioB<=318.00){
        isr= salarioB - 0.01;
        isr=isr*0.0192;
        isr=isr+0.0;
        }else if(salarioB>=318.01 && salarioB<=2699.40){
        isr= salarioB-318.01;
        isr=isr*0.0640;
        isr=isr+6.15;
        }else if(salarioB>=2699.41 && salarioB<=4744.05){
        isr= salarioB-2699.41;
        isr=isr*0.1088;
        isr=isr+158.55;
        }else if(salarioB >=4744.06 && salarioB<=5514.75){
        isr= salarioB-4744.06;
        isr=isr*0.16;
        isr=isr+381;
        }else if(salarioB>=5514.76 && salarioB<=6602.70){
        isr= salarioB-5514.76;
        isr=isr*0.1792;
        isr=isr+504.30;
        }else if(salarioB >=6602.71 && salarioB <=13316.70){
        isr= salarioB -6602.72;
        isr=isr*0.2136;
        isr=isr+699.30;
        }else if(salarioB >=13316.71 && salarioB<=20988.90){
        isr= salarioB-13316.71;
        isr=isr*0.2352;
        isr=isr+2133.30;
        }else if(salarioB>=20988.91 && salarioB<=40071.30){
        isr= salarioB -20988.91;
        isr=isr*0.3;
        isr=isr+3937.80;
        }
        return isr;
    }

    public void setIsr(double isr) {
        this.isr = isr; 
    }    
}
