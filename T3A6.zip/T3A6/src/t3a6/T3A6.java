package t3a6;

public class T3A6 {

    public static void main(String[] args) {
        operacion();
    }
        public static void operacion() {
                Nomina n = new Nomina();
        n.Nomina();
    }
}
