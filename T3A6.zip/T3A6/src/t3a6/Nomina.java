/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package t3a6;

import java.util.Scanner;

/**
 *
 * @author Cody
 */
public class Nomina {

    public void Nomina() {

        Scanner sc = new Scanner(System.in);

        Calculos c = new Calculos();

        System.out.println("Ingrese el numero de empleados");
        int m = sc.nextInt();
        int i = 1;
        for (i = i; i <= m; i++) {

            System.out.print("Ingrese su nombre: ");
            String nombre = sc.next();

            System.out.print("Ingrese sus apellidos: ");
            String apellidos = sc.next();

            System.out.print("Ingerse su RFC: ");
            String rfc = sc.next();

            System.out.print("Ingrese su CURP: ");
            String curp = sc.next();

            System.out.print("Ingrese su Email: ");
            String email = sc.next();

            System.out.print("Ingrese su telefono: ");
            String telefono = sc.next();

            System.out.print("Ingrese su numero de contrato: ");
            int noContrato = sc.nextInt();

            System.out.print("¿Que tipo de empleado es?\n 1.Administrativo\n2.Otro\nIngrese el numero de la opcion: ");
            int tipoEmpleado = sc.nextInt();
            c.setTipoEmpleado(tipoEmpleado);

            System.out.print("Ingrese sus años de antiguedad: ");

            int añosAntiguedad = sc.nextInt();
            c.setAñosAntiguedad(añosAntiguedad);

            System.out.print("Ingrese sus horas laborales mensuales: ");

            int hoLaborales = sc.nextInt();

            System.out.print("Ingrese su salario base mensual: ");

            double salarioBase = sc.nextDouble();
            c.setSalarioBase(salarioBase);
            c.getBono();
            c.getIsr();

            System.out.println("REPORTE DE SALARIOS\n "
                    + "Nombre: " + nombre + " " + apellidos
                    + "\nCURP: " + curp
                    + "\nRFC: " + rfc
                    + "\nEmail: " + email
                    + "\nTelefono: " + telefono
                    + "\n\nSu numero de contrato es: " + noContrato
                    + "\n Su numero de horas laborales mensuales son: " + hoLaborales
                    + "\n" + c.toString());
        }
    }
}
